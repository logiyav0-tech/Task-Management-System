package com.yamaha.entity;

public enum TaskPriority {
    LOW, MEDIUM, HIGH, URGENT
}