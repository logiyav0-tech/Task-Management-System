package com.yamaha.entity;

public enum TaskStatus {
    NOT_STARTED, IN_PROGRESS, COMPLETED, HOLD
}