package com.yamaha.entity;

public enum UserRole {
    ADMIN, SUPERVISOR, OPERATOR, VIEWER
}