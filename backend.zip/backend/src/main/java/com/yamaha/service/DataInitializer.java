package com.yamaha.service;

import com.yamaha.entity.User;
import com.yamaha.entity.UserRole;
import com.yamaha.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private TaskService taskService;
    
    @Override
    public void run(String... args) throws Exception {
        initializeUsers();
        taskService.initializeSampleData();
    }
    
    private void initializeUsers() {
        if (userRepository.count() == 0) {
            // Admin User
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setFullName("System Administrator");
            admin.setEmail("admin@yamaha.com");
            admin.setRole(UserRole.ADMIN);
            userRepository.save(admin);
            
            // Supervisor User
            User supervisor = new User();
            supervisor.setUsername("supervisor");
            supervisor.setPassword(passwordEncoder.encode("supervisor123"));
            supervisor.setFullName("Production Supervisor");
            supervisor.setEmail("supervisor@yamaha.com");
            supervisor.setRole(UserRole.SUPERVISOR);
            userRepository.save(supervisor);
            
            // Operator User
            User operator = new User();
            operator.setUsername("operator");
            operator.setPassword(passwordEncoder.encode("operator123"));
            operator.setFullName("Production Operator");
            operator.setEmail("operator@yamaha.com");
            operator.setRole(UserRole.OPERATOR);
            userRepository.save(operator);
            
            // Viewer User
            User viewer = new User();
            viewer.setUsername("viewer");
            viewer.setPassword(passwordEncoder.encode("viewer123"));
            viewer.setFullName("Quality Viewer");
            viewer.setEmail("viewer@yamaha.com");
            viewer.setRole(UserRole.VIEWER);
            userRepository.save(viewer);
            
            System.out.println("Default users initialized successfully");
        }
    }
}